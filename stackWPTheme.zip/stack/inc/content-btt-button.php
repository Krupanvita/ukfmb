<a class="back-to-top inner-link" title="<?php esc_attr_e('Back to top', 'stack'); ?>" href="#start" data-scroll-class="100vh:active">
	<i class="stack-interface stack-up-open-big"></i>
</a>