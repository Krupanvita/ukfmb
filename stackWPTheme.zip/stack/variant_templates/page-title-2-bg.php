<!--META--><section class="vim" id="variant-page-title-2-bg" vbr="Page Title 2 BG" vbp="titles">
<section class=" imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="wysiwyg"><h1>Breadcrumb Title</h1></div>
				<div class="variant-shortcode" data-shortcode-name="stack_breadcrumbs_variant"></div>
				<hr>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->