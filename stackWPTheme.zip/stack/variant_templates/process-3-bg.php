<!--META--><section class="vim" id="variant-process-3-bg" vbr="Process 3 BG" vbp="process">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-md-8 col-md-offset-2">
                <div class="row">
                    <div class="col-sm-6 voh">
                        <div class="feature feature-3 boxed boxed--lg boxed--border wysiwyg">
                            <span class="h1 h1--large">1.</span>
                            <h4>Launch Builder</h4>
                            <p>
                                Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out
                            </p>
                        </div><!--end boxed-->
                    </div>
                    <div class="col-sm-6 voh">
                        <div class="feature feature-3 boxed boxed--lg boxed--border wysiwyg">
                            <span class="h1 h1--large">2.</span>
                            <h4>Build With Blocks</h4>
                            <p>
                                Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out
                            </p>
                        </div><!--end boxed-->
                    </div>
                    <div class="col-sm-6 voh">
                        <div class="feature feature-3 boxed boxed--lg boxed--border wysiwyg">
                            <span class="h1 h1--large">3.</span>
                            <h4>Export Code</h4>
                            <p>
                                Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out
                            </p>
                        </div><!--end boxed-->
                    </div>
                    <div class="col-sm-6 voh">
                        <div class="feature feature-3 boxed boxed--lg boxed--border wysiwyg">
                            <span class="h1 h1--large">4.</span>
                            <h4>Deploy Site</h4>
                            <p>
                                Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out
                            </p>
                        </div><!--end boxed-->
                    </div>  
                </div><!--end of row-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->