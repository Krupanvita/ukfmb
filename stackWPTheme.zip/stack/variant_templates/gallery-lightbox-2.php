<!--META--><section class="vim" id="variant-gallery-lightbox-2" vbr="Gallery Lightbox 2" vbp="gallery">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="masonry">
                <div class="masonry-filter-container text-center">
                    <span>Category:</span>
                    <div class="masonry-filter-holder">
                        <div class="masonry__filters" data-filter-all-text="All Categories"></div>
                    </div>
                </div><!--end masonry filters-->
                <div class="masonry__container">
                    <div class="masonry__item col-md-4 col-xs-6 voh vnn" data-masonry-filter="People">
                        <a href="<?php variant_page_builder_demo_img('work-6.jpg'); ?>" data-lightbox="Gallery 1" data-title="">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
                        </a>
						<div class="text-block">
							<h4>Gallery Item Title</h4>
							<p>Gallery Item Description</p>
						</div>
                    </div>
                    <div class="masonry__item col-md-4 col-xs-6 voh vnn" data-masonry-filter="People">
                        <a href="<?php variant_page_builder_demo_img('work-3.jpg'); ?>" data-lightbox="Gallery 1" data-title="">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-3.jpg'); ?>">
                        </a>
						<div class="text-block">
							<h4>Gallery Item Title</h4>
							<p>Gallery Item Description</p>
						</div>
                    </div>
                    
                    
                    
                    
                </div><!--end masonry container-->
            </div><!--end masonry-->
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->