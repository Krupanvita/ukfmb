<!--META--><section class="vim" id="variant-subscribe-boxed-2" vbr="Subscribe Boxed 2" vbp="subscribes">
<section class="text-center ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <div class="boxed boxed--lg bg--dark subscribe-form-1">
                    <div class="wysiwyg">
                    	<h3>Get our latest content in your inbox</h3>
                    	<h5>Join over 40,000 satisfied customers</h5>
                    </div>
                    <div class="col-sm-8 col-sm-offset-2 text-left">
                        <div class="cf7-holder">
                        	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                        		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->