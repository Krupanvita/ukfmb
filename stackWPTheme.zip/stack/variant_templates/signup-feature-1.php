<!--META--><section class="vim" id="variant-signup-feature-1" vbr="Signup Feature 1" vbp="signup">
<section class="switchable ">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-5">
                <div class="mt--3">
                	<div class="wysiwyg">
	                    <h1>Ideal for design conscious startups.</h1>
	                    <p class="lead">
	                        Start building a beautiful site for your startup — right in the comfort of your browser.
	                    </p>
	                    <hr class="short">
                    </div>
                    <div class="cf7-holder">
                    	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                    		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                    	</div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-5">
                <img alt="Image" class="border--round box-shadow-wide" src="<?php variant_page_builder_demo_img('photography-9.jpg'); ?>">
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->