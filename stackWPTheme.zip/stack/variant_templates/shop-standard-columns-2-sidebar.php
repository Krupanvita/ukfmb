<!--META--><section class="vim" id="variant-shop-standard-columns-2-sidebar" vbr="Shop Standard 2 Columns + Sidebar" vbp="shop">
<section>
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_product" data-param-layout="column-sidebar" data-param-pppage="6" data-param-filter="all"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->