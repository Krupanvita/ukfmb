<!--META--><section class="vim" id="variant-in-page-navigator" vbr="In Page Navigator" vbp="utility">
<section class="page-navigator">
    <ul>
        <li class="voh">
            <a href="#section1" class="inner-link" data-title="Section 1"></a>
        </li>
        <li class="voh">
            <a href="#section2" class="inner-link" data-title="Section 2"></a>
        </li>
        <li class="voh">
            <a href="#section3" class="inner-link" data-title="Section 3"></a>
        </li>
    </ul>
</section>
</section><!--end of meta Section container-->