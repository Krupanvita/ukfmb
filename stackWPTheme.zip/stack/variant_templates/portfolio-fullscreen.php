<!--META--><section class="vim" id="variant-portfolio-fullscreen" vbr="Portfolio Fullscreen Slider" vbp="portfolio">
<section class="text-center unpad--top unpad--bottom">

        <div class="variant-shortcode" data-shortcode-name="stack_portfolio" data-param-layout="fullscreen" data-param-pppage="4" data-param-filter="all" data-param-arrows="true" data-param-paging="true" data-param-timing="9000" data-param-offset="0"></div>

</section>
</section><!--end of meta Section container-->