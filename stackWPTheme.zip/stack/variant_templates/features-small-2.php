<!--META--><section class="vim" id="variant-features-small-2" vbr="Features Small 2" vbp="features small">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-4 voh">
                <div class="feature feature-2 boxed boxed--border">
                    <i class="icon icon-Clock-Back color--primary"></i>
                    <div class="feature__body wysiwyg">
                        <p>
                            Save time with a multitude of styled components designed to showcase your content
                        </p>
                    </div>
                </div><!--end feature-->
            </div>
            <div class="col-sm-4 voh">
                <div class="feature feature-2 boxed boxed--border">
                    <i class="icon icon-Duplicate-Window color--primary"></i>
                    <div class="feature__body wysiwyg">
                        <p>
                            Construct mockups or production-ready pages in-browser with Variant Page Builder
                        </p>
                    </div>
                </div><!--end feature-->
            </div>
            <div class="col-sm-4 voh">
                <div class="feature feature-2 boxed boxed--border">
                    <i class="icon icon-Life-Jacket color--primary"></i>
                    <div class="feature__body wysiwyg">
                        <p>
                            Take comfort in 6 months included support with a dedicated support forum
                        </p>
                    </div>
                </div><!--end feature-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->