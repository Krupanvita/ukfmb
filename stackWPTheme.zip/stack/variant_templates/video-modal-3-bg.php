<!--META--><section class="vim" id="variant-video-modal-3-bg" vbr="Video Modal 3 BG" vbp="media">
<section class="video video-1 text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="modal-instance vog">
					<div class="video-play-icon video-play-icon--sm modal-trigger box-shadow vog"></div>
					<div class="modal-container vog">
						<div class="modal-content bg-dark vog" data-width="60%" data-height="60%">
							<iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
						</div><!--end of modal-content-->
					</div><!--end of modal-container-->
				</div><!--end of modal instance-->
				<h2>Streamline your workflow with Stack</h2>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->