<!--META--><section class="vim" id="variant-shortcode-layout-1-bg" vbr="Shortcode Layout 1 BG" vbp="shortcodes">
<section class="text-center imagebg">
    
	<div class="background-image-holder">
	    <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
	</div>
	
    <div class="container">
        <div class="shortcode-holder lead" data-shortcode="">Add your shortcode to the settings for this section &rarr;</div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->