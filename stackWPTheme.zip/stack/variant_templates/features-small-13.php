<!--META--><section class="vim" id="variant-features-small-13" vbr="Features Small 13" vbp="features small">
<section class="text-center ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-3">
                <div class="text-block voh">
                    <i class="icon icon--lg icon-Mail-3"></i>
                    <div class="wysiwyg">
	                    <h4>Mailer Integrations</h4>
	                    <p>
	                        for marketing campaigns
	                    </p>
                    </div>
                </div><!--end feature-->
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="text-block voh">
                    <i class="icon icon--lg icon-Air-Balloon"></i>
                    <div class="wysiwyg">
	                    <h4>Diverse Icons</h4>
	                    <p>
	                        from a library over over 1,000
	                    </p>
                    </div>
                </div><!--end feature-->
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="text-block voh">
                    <i class="icon icon--lg icon-Bacteria"></i>
                    <div class="wysiwyg">
	                    <h4>Modular Design</h4>
	                    <p>
	                        for maximum flexibility
	                    </p>
                    </div>
                </div><!--end feature-->
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="text-block voh">
                    <i class="icon icon--lg icon-Fingerprint-2"></i>
                    <div class="wysiwyg">
	                    <h4>Modular Design</h4>
	                    <p>
	                        for maximum flexibility
	                    </p>
                    </div>
                </div><!--end feature-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->