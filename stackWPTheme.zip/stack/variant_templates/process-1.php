<!--META--><section class="vim" id="variant-process-1" vbr="Process 1" vbp="process">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
                <div class="process-1">
                    <div class="process__item voh wysiwyg">
                        <h4>Company established 2012<br> 4 founding members</h4>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                    <div class="process__item voh wysiwyg">
                        <h4>Succsessfully funded through<br> Bray Investments</h4>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                    <div class="process__item voh wysiwyg">
                        <h4>Posted profit<br> second quarter 2015</h4>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                </div><!--end process-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->