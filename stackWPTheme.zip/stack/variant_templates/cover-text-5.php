<!--META--><section class="vim" id="variant-cover-text-5" vbr="Cover Text 5" vbp="covers">
<section class="cover imagebg height-100 text-center" data-overlay="3">
    <div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('landing-10.jpg'); ?>"></div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-9 col-md-8 wysiwyg">
            	<h1>Streamline your workflow with Stack</h1>
                <p class="lead">Stack offers a clean and contemporary look to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.</p>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
    <div class="pos-absolute pos-bottom col-xs-12">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-left">
                    <div class="text-block voh wysiwyg">
                        <h5>Teahupo'o Beach</h5>
                        <span>French Polynesia</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</section><!--end of meta Section container-->