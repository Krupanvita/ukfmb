<!--META--><section class="vim" id="variant-twitter-feed-2-gradient" vbr="Twitter Feed 2 Gradient" vbp="social">
<section class="text-center imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-6">
                <div class="heading-block wysiwyg">
                    <h2>Follow us @tommusrhodus</h2>
                </div>
                <div class="text-left tweets-feed tweets-feed-1 bg--secondary" data-feed-name="tommusrhodus" data-amount="3"></div>
                <a class="btn btn--icon bg--twitter" href="#">
                    <span class="btn__text">
                        <i class="socicon socicon-twitter"></i>
                        Visit @tommusrhodus on Twitter
                    </span>
                </a>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->