<!--META--><section class="vim" id="variant-subscribe-video-1" vbr="Subscribe Video 1" vbp="subscribes">
<section class="imageblock switchable feature-large height-100 ">
    <div class="imageblock__content col-md-6 col-sm-4 pos-right" data-overlay="1">
        <div class="background-image-holder">
            <img alt="image" src="<?php variant_page_builder_demo_img('inner-9.jpg'); ?>">
        </div>
        <div class="modal-instance vog">
            <div class="video-play-icon modal-trigger vog"></div>
            <div class="modal-container vog">
                <div class="modal-content bg-dark vog" data-width="60%" data-height="60%">
                    <iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
                </div><!--end of modal-content-->
            </div><!--end of modal-container-->
        </div><!--end of modal instance-->
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-md-5 col-sm-7">
            	<div class="wysiwyg">
	                <h1>Build a next-level product page in your browser.</h1>
	                <p class="lead">
	                    Stack offers a clean and contemporary look to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.
	                </p>
                </div>
                <div class="bg--secondary boxed boxed--border cf7-holder">
                	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                	</div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->