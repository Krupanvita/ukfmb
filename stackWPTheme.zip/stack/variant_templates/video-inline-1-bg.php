<!--META--><section class="vim" id="variant-video-inline-1-bg" vbr="Video Inline 1 BG" vbp="media">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-6">
				<div class="wysiwyg"><h2>Building beautiful sites is easy</h2></div>
				<div class="video-cover border--round">
					<div class="background-image-holder">
						<img alt="image" src="<?php variant_page_builder_demo_img('blog-3.jpg'); ?>">
					</div>
					<div class="video-play-icon"></div>
					<iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
				</div><!--end video cover-->
				<div class="wysiwyg">
					<span>Stack includes Variant Page Builder — used by over <strong>17,000</strong> customers <a target="_blank" href="#customise-template">Try Now  ↗</a></span>
				</div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->