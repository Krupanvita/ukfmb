<!--META--><section class="vim" id="variant-twitter-slider-1-gradient" vbr="Twitter Slider 1 Gradient" vbp="social">
<section class="text-center imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 variant-disable-vjr">
                <div class="tweets-feed slider text-center variant-disable-vjr" data-feed-name="tommusrhodus" data-amount="5" data-paging="true"></div>
                <a class="btn btn--icon bg--twitter" href="#">
                    <span class="btn__text">
                        <i class="socicon socicon-twitter"></i>
                        Visit @tommusrhodus on Twitter
                    </span>
                </a>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->