<!--META--><section class="vim" id="variant-subscribe-horizontal-4" vbr="Subscribe Horizontal 4" vbp="subscribes">
<section class="subscribe-form-2 space--xs ">
    
    <div class="container">
        <div class="row">
            <div class="col-md-4 wysiwyg">
                <p class="lead">Subscribe for our monthly newsletter</p>
            </div>
            <div class="col-md-7 col-md-offset-1">
                <div class="cf7-holder">
                	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                	</div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->