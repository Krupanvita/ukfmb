<!--META--><section class="vim" id="variant-testimonial-partners-1" vbr="Testimonial Partners 1" vbp="testimonials">
<section class="testimonials-1 space--xs ">
	
	<div class="container">
		<div class="row">
			<div class="col-sm-4 wysiwyg">
				<p class="lead">
					Trusted by over 40,000 customers <br class="hidden-xs hidden-sm">
					in over 140 countries
				</p>
			</div>
			<div class="col-sm-8">
				<ul class="list-inline social-list">
					<li class="voh">
						<img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-3.png'); ?>">
					</li>
					<li class="voh">
						<img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-2.png'); ?>">
					</li>
					<li class="voh">
						<img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-4.png'); ?>">
					</li>
					<li class="voh">
						<img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-5.png'); ?>">
					</li>
					<li class="voh">
						<img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-6.png'); ?>">
					</li>
				</ul>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->