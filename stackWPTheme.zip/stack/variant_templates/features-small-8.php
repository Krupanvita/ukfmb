<!--META--><section class="vim" id="variant-features-small-8" vbr="Features Small 8" vbp="features small">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-xs-6 voh">
                <a href="#" class="block">
                    <div class="feature feature-7 boxed text-center imagebg" data-overlay="3">
                        <div class="background-image-holder">
                            <img alt="background" src="<?php variant_page_builder_demo_img('blog-1.jpg'); ?>">
                        </div>
                        <h4 class="pos-vertical-center">Startups</h4>
                    </div>
                </a>
            </div>
            <div class="col-sm-4 col-xs-6 voh">
                <a href="#" class="block">
                    <div class="feature feature-7 boxed text-center imagebg" data-overlay="3">
                        <div class="background-image-holder">
                            <img alt="background" src="<?php variant_page_builder_demo_img('cowork-1.jpg'); ?>">
                        </div>
                        <h4 class="pos-vertical-center">Teams</h4>
                    </div>
                </a>
            </div>
            <div class="col-sm-4 col-xs-6 voh">
                <a href="#" class="block">
                    <div class="feature feature-7 boxed text-center imagebg" data-overlay="3">
                        <div class="background-image-holder">
                            <img alt="background" src="<?php variant_page_builder_demo_img('education-1.jpg'); ?>">
                        </div>
                        <h4 class="pos-vertical-center">Freelancers</h4>
                    </div>
                </a>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->