<!--META--><section class="vim" id="variant-cta-centered-3" vbr="CTA Centered 3" vbp="CTA">
<section class="text-center ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-6">
                <div class="cta">
                    <a class="btn btn--primary btn--lg type--uppercase" href="#purchase-template">
                        <span class="btn__text">
                            Purchase Stack
                        </span>
                        <span class="label">$59 USD</span>
                    </a>
                    <div class="wysiwyg">
	                    <p class="lead">
	                        Each purchase of Stack comes with six months free support — and a lifetime of free content and bug-fix updates.
	                    </p>
	                    <p class="type--fine-print">or check out <a href="/">more demos</a></p>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->