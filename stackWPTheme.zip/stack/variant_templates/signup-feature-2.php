<!--META--><section class="vim" id="variant-signup-feature-2" vbr="Signup Feature 2" vbp="signup">
<section class="space--xs imageblock switchable feature-large ">
    <div class="imageblock__content col-md-6 col-sm-4 pos-right">
        <div class="background-image-holder">
            <img alt="image" src="<?php variant_page_builder_demo_img('landing-5.jpg'); ?>">
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-7">
            	<div class="wysiwyg">
                	<h2>Create an account</h2>
                	<p class="lead">Get started with a 14 day free trial,<br class="hidden-xs hidden-sm"> No credit card required.</p>
                </div>
                <div class="cf7-holder">
                	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                	</div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->