<!--META--><section class="vim" id="variant-twitter-feed-1" vbr="Twitter Feed 1" vbp="social">
<section class="switchable ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-5">
                <div class="switchable__text">
                	<div class="wysiwyg">
	                    <h2>Follow us for news, updates and competitions</h2>
	                    <p class="lead">
	                        Launching an attractive and scalable website quickly and affordably is important for modern startups — Stack offers massive value without looking 'bargain-bin'.
	                    </p>
                    </div>
                    <a class="btn btn--icon bg--twitter" href="#">
                        <span class="btn__text">
                            <i class="socicon socicon-twitter"></i>
                            Visit @tommusrhodus on Twitter
                        </span>
                    </a>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="tweets-feed tweets-feed-1 bg--secondary" data-feed-name="tommusrhodus" data-amount="3"></div>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->