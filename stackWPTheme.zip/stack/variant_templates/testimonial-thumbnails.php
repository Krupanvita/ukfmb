<!--META--><section class="vim" id="variant-testimonial-thumbnails" vbr="Testimonial Thumbnails" vbp="testimonials">
<section class="text-center ">
    
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-sm-10 variant-disable-vjr">
				<div class="variant-shortcode" data-shortcode-name="stack_testimonial" data-param-layout="thumbnails" data-param-pppage="6" data-param-filter="all"></div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->