<section class="vim" id="variant-features-small-14" vbr="Features Small 14" vbp="features small">
<section class="features-small-14 text-center">
    
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="text-block voh">
                            <i class="icon color--dark icon-Preview"></i>
                            <h4>Showcase Products</h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="text-block voh">
                            <i class="icon color--dark icon-Post-Mail2"></i>
                            <h4>Mailer Integrations</h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="text-block voh">
                            <i class="icon color--dark icon-Fingerprint-2"></i>
                            <h4>Infinitely Customisable</h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="text-block voh">
                            <i class="icon color--dark icon-Life-Safer"></i>
                            <h4>Dedicated Support Team</h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="text-block voh">
                            <i class="icon color--dark icon-Duplicate-Window"></i>
                            <h4>Modular Markup and Design</h4>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="text-block voh">
                            <i class="icon color--dark icon-Clock-Back"></i>
                            <h4>Save Time</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</section>