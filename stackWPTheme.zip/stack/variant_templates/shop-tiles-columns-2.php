<!--META--><section class="vim" id="variant-shop-tiles-columns-2" vbr="Shop Tiles 2 Columns" vbp="shop">
<section class="text-center ">
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_product" data-param-layout="column-tiles-2" data-param-pppage="6" data-param-filter="all"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->