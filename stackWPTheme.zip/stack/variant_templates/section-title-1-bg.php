<!--META--><section class="vim" id="variant-section-title-1-bg" vbr="Section Title 1 BG" vbp="titles">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-10 col-md-8 wysiwyg">
				<h2>Section Title Centered</h2>
				<p class="lead">
					Stack's visual style is simple yet distinct, making it an ideal starting point for your project whether it be a basic marketing site, or multi-page company presence.
				</p>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->