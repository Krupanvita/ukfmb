<!--META--><section class="vim" id="variant-text-layout-7" vbr="Typed Text Headline" vbp="titles">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="typed-headline">
                	<span class="h2 inline-block">I'm Stack — A killer template for</span>
                	<span class="h2 inline-block typed-text typed-text--cursor color--primary" data-typed-strings="startups,SaaS,marketing sites, portfolios,blogging,rapid development,business,showcasing products"> </span>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->