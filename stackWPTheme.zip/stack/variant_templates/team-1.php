<!--META--><section class="vim" id="variant-team-1" vbr="Team 1" vbp="team">
<section class="text-center ">
    <div class="container">	
    	<div class="variant-shortcode" data-shortcode-name="stack_team" data-param-layout="grid-3" data-param-pppage="6" data-param-filter="all" data-param-offset="0"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->