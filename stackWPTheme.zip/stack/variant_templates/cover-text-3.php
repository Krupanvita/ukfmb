<!--META--><section class="vim" id="variant-cover-text-3" vbr="Cover Text 3" vbp="covers">
<section class="cover height-80 imagebg text-center" data-overlay="5">
	<div class="background-image-holder background--top">
		<img alt="background" src="<?php variant_page_builder_demo_img('landing-1.jpg'); ?>">
	</div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-8">
				<div class="wysiwyg">
					<img alt="Image" class="unmarg--bottom" src="<?php variant_page_builder_demo_img('headline-1.png'); ?>">
					<h3>Streamline your workflow with Stack.</h3>
				</div>
				<a class="btn btn--primary type--uppercase" href="#">
					<span class="btn__text">
						View The Demos
					</span>
				</a>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->