<!--META--><section class="vim" id="variant-features-large-4" vbr="Features Large 4" vbp="features large">
<section class="imageblock switchable feature-large ">
    <div class="imageblock__content col-md-6 col-sm-4 pos-right">
        <div class="background-image-holder">
            <img alt="image" src="<?php variant_page_builder_demo_img('education-5.jpg'); ?>">
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-7 wysiwyg">
                <h2>Stack is design-driven</h2>
                <p class="lead">
                    Stack offers a clean and contemporary to suit a range of purposes from corporate, tech startup, marketing site to digital storefront. Elements have been designed to showcase content in a diverse yet consistent manner.
                </p>
                <p class="lead">
                    Multiple font and colour scheme options mean that dramatically altering the look of your site is just clicks away — Customizing your site in the included Variant Page Builder makes experimenting with styles and content arrangements dead simple.
                </p>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->