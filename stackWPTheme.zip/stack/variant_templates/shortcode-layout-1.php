<!--META--><section class="vim" id="variant-shortcode-layout-1" vbr="Shortcode Layout 1" vbp="shortcodes">
<section class="text-center">
    
    <div class="container">
        <div class="shortcode-holder lead" data-shortcode="">Add your shortcode to the settings for this section &rarr;</div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->