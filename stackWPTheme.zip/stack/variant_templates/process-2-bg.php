<!--META--><section class="vim" id="variant-process-2-bg" vbr="Process 2 BG" vbp="process">
<section class=" imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="process-2">
                <div class="col-sm-3 voh">
                    <div class="process__item wysiwyg">
                        <h5>Company established 2012<br> 4 founding members</h5>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                </div>
                <div class="col-sm-3 voh">
                    <div class="process__item wysiwyg">
                        <h5>Succsessfully funded through<br> Bray Investments</h5>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                </div>
                <div class="col-sm-3 voh">
                    <div class="process__item wysiwyg">
                        <h5>Posted profit<br> second quarter 2015</h5>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                </div>
                <div class="col-sm-3 voh">
                    <div class="process__item wysiwyg">
                        <h5>Posted profit<br> second quarter 2015</h5>
                        <p>
                            Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                        </p>
                    </div>
                </div>
            </div><!--end process-->
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->