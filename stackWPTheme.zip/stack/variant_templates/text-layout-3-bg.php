<!--META--><section class="vim" id="variant-text-layout-3-bg" vbr="Text Layout 3 BG" vbp="text">
<section class=" imagebg" data-overlay="5">
	
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
        <div class="row">
            <div class="col-sm-4 voh">
                <div class="feature wysiwyg">
                    <h4>Interactive Elements</h4>
                    <p>
                        With rich modal and notification functionality and a robust suite of options, Stack makes building feature-heavy pages simple and enjoyable.
                    </p>
                </div>
            </div>
            <div class="col-sm-4 voh">
                <div class="feature wysiwyg">
                    <h4>Save Development Time</h4>
                    <p>
                        Drastically reduce the time it takes to move from initial concept to production-ready with Stack and Variant Page Builder. Your clients will love you for it!
                    </p>
                </div>
            </div>
            <div class="col-sm-4 voh">
                <div class="feature wysiwyg">
                    <h4>Friendly Support</h4>
                    <p>
                        Our customers love the comfort that comes with six-months free support. Our dedicated support forum makes interacting with us hassle-free and efficient.
                    </p>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->