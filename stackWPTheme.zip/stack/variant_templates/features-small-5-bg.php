<!--META--><section class="vim" id="variant-features-small-5-bg" vbr="Features Small 5 BG" vbp="features small">
<section class=" imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-6 voh">
                <div class="feature feature-5 boxed boxed--lg boxed--border">
                    <i class="icon icon-Pantone icon--lg"></i>
                    <div class="feature__body wysiwyg">
                        <h5>Highly Customizable</h5>
                        <p>
                            Stack's visual style is simple yet distinct perfect for any project whether it be a basic marketing site, or multi-page company presence.
                        </p>
                        <a href="#">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 voh">
                <div class="feature feature--featured feature-5 boxed boxed--lg boxed--border">
                    <i class="icon icon-Fingerprint icon--lg"></i>
                    <div class="feature__body wysiwyg">
                        <h5>Built For Startups</h5>
                        <p>
                            Launching an attractive website quickly and affordably is important for modern startups — Stack offers massive value with modern styling.
                        </p>
                        <a href="#">Learn More</a>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->