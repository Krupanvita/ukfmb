<!--META--><section class="vim" id="variant-testimonial-slider-1-bg" vbr="Testimonial Slider 1 BG" vbp="testimonials">
<section class=" imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-12 variant-disable-vjr">
				<div class="variant-shortcode" data-shortcode-name="stack_testimonial" data-param-layout="slider-1" data-param-pppage="6" data-param-filter="all"></div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->