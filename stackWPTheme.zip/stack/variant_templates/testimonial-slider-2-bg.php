<!--META--><section class="vim" id="variant-testimonial-slider-2-bg" vbr="Testimonial Slider 2 BG" vbp="testimonials">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-sm-10 variant-disable-vjr">
				<div class="variant-shortcode" data-shortcode-name="stack_testimonial" data-param-layout="slider-2" data-param-pppage="6" data-param-filter="all"></div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->