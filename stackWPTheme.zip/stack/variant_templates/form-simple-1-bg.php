<!--META--><section class="vim" id="variant-form-simple-1-bg" vbr="Form Simple 1 BG" vbp="contact">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-7">
                <div class="row">
                    <div class="cf7-holder">
                    	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                    		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                    	</div>
                    </div>
                </div><!--end of row-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->