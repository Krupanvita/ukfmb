<!--META--><section class="vim" id="variant-process-radial-2" vbr="Process Radial 2" vbp="process">
<section class="switchable feature-large ">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-5">
                <div class="radial" data-value="100" data-size="260" data-bar-width="8" data-color="<?php echo get_option('color_primary', '#4A90E2'); ?>">
                    <i class="icon icon--lg icon-Road-3 color--primary radial__label"></i>
                </div><!--end radial-->
            </div>
            <div class="col-sm-6 col-md-5">
                <div>
                	<div class="wysiwyg">
	                    <h2>Design and launch your startup's website in no time.</h2>
	                    <p class="lead">
	                        Launching an attractive and scalable website quickly and affordably is important for modern startups — Stack offers massive value without looking 'bargain-bin'.
	                    </p>
	                    <a href="#">Learn More »</a>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->