<!--META--><section class="vim" id="variant-gallery-products-1" vbr="Gallery Products 1" vbp="gallery">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="masonry">
                <div class="masonry-filter-container text-center">
                    <span>Category:</span>
                    <div class="masonry-filter-holder">
                        <div class="masonry__filters" data-filter-all-text="All Categories"></div>
                    </div>
                </div><!--end masonry filters-->
                <div class="masonry__container">
                    <div class="masonry__item col-sm-4 voh vnn"></div>
                    <div class="masonry__item col-sm-4 voh vnn" data-masonry-filter="Audio">
                        <div class="product">
                            <a href="#">
                                <img alt="Image" src="<?php variant_page_builder_demo_img('product-small-10.png'); ?>">
                            </a>
                            <a class="block" href="#">
                                <div>
                                    <h5>DALI Xensor 2</h5><span> Desktop Speaker</span>
                                </div>
                                <div>
                                    <span class="h4 inline-block">$269</span>
                                </div>
                            </a>
                        </div>
                    </div><!--end item-->
                    <!--end item-->
                    <!--end item-->
                    <!--end item-->
                    <!--end item-->
                    <!--end item-->
                </div><!--end masonry container-->
            </div><!--end masonry-->
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->