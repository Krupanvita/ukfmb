<!--META--><section class="vim" id="variant-portfolio-titles-outside-3" vbr="Portfolio Titles Outside 3 Columns" vbp="portfolio">
<section class="text-center ">
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_portfolio" data-param-layout="titles-outside-3" data-param-pppage="6" data-param-filter="all" data-param-offset="0"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->