<!--META--><section class="vim" id="variant-testimonial-avatar-1-bg" vbr="Testimonial Avatar 1 BG" vbp="testimonials">
<section class="space--sm unpad--bottom switchable text-center testimonial testimonial-1 imagebg" data-overlay="4">
	
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-md-5">
				<img alt="Image" src="<?php variant_page_builder_demo_img('avatar-large-1.png'); ?>">
			</div>
			<div class="col-sm-6">
				<div class="switchable__text wysiwyg">
					<blockquote>
						“There's a feeling of structure that you can't find in other themes — Stack has become my default template.”
					</blockquote>
					<h5>Jason Briggs</h5>
					<span>Envato Customer</span>
				</div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->