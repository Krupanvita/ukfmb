<!--META--><section class="vim" id="variant-slider-images" vbr="Slider Images" vbp="slider">
<section class=" ">
    
    <div class="container">
        <div class="row variant-disable-vjr">
            <div class="slider variant-disable-vjr" data-arrows="true" data-paging="true">
                <ul class="slides variant-disable-vjr">
                    <li>
                        <img alt="Image" src="<?php variant_page_builder_demo_img('work-1.jpg'); ?>">
                    </li>
                    <li>
                        <img alt="Image" src="<?php variant_page_builder_demo_img('work-2.jpg'); ?>">
                    </li>
                    <li>
                        <img alt="Image" src="<?php variant_page_builder_demo_img('work-3.jpg'); ?>">
                    </li>
                    <li>
                        <img alt="Image" src="<?php variant_page_builder_demo_img('work-4.jpg'); ?>">
                    </li>
                    <li>
                        <img alt="Image" src="<?php variant_page_builder_demo_img('work-5.jpg'); ?>">
                    </li>
                    <li>
                        <img alt="Image" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
                    </li>
                </ul>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->