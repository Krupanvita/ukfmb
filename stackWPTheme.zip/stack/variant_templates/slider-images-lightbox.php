<!--META--><section class="vim" id="variant-slider-images-lightbox" vbr="Slider Images Lightbox" vbp="slider">
<section class=" ">
    
    <div class="container">
        <div class="row variant-disable-vjr">
            <div class="slider slider--columns variant-disable-vjr" data-arrows="true" data-paging="true">
                <ul class="slides variant-disable-vjr">
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-6.jpg'); ?>" data-lightbox="Gallery 1">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
                        </a>
                    </li>
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-5.jpg'); ?>" data-lightbox="Gallery 1">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-5.jpg'); ?>">
                        </a>
                    </li>
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-4.jpg'); ?>" data-lightbox="Gallery 1">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-4.jpg'); ?>">
                        </a>
                    </li>
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-3.jpg'); ?>" data-lightbox="Gallery 1">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-3.jpg'); ?>">
                        </a>
                    </li>
                </ul>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->