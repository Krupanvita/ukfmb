<!--META--><section class="vim" id="variant-gallery-projects-5" vbr="Gallery Projects 5" vbp="gallery">
<section>
        <div class="masonry masonry--gapless">
        <div class="masonry-filter-container text-center">
            <span>Category:</span>
            <div class="masonry-filter-holder">
                <div class="masonry__filters" data-filter-all-text="All Categories"></div>
            </div>
        </div>
        <div class="masonry__container bg--secondary">
            <div class="col-sm-4 col-xs-12 masonry__item voh vnn" data-masonry-filter="Marketing">
                <div class="project-thumb hover-element height-40">
                    <a href="#">
                        <div class="hover-element__initial">
                            <div class="background-image-holder">
                                <img alt="background" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
                            </div>
                        </div>
                        <div class="hover-element__reveal" data-overlay="9">
                            <div class="project-thumb__title">
                                <h5>Nike Active</h5>
                                <span>Digital Marketing</span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-4 col-xs-12 masonry__item voh vnn" data-masonry-filter="Design">
                <div class="project-thumb hover-element height-40">
                    <a href="#">
                        <div class="hover-element__initial">
                            <div class="background-image-holder">
                                <img alt="background" src="<?php variant_page_builder_demo_img('work-1.jpg'); ?>">
                            </div>
                        </div>
                        <div class="hover-element__reveal" data-overlay="9">
                            <div class="project-thumb__title">
                                <h5>Unvest Capital</h5>
                                <span>Brand Collateral</span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            
        </div><!--end of masonry__container-->
    </div><!--end of masonry-->
</section>
</section><!--end of meta Section container-->