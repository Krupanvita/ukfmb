<!--META--><section class="vim" id="variant-carousel-logo" vbr="Carousel Logo" vbp="carousel">
<section class=" ">
    
    <div class="container">
        <div class="row variant-disable-vjr">
            <div class="logo-carousel slider slider--inline-arrows slider--arrows-hover text-center variant-disable-vjr" data-arrows="true">
                <ul class="slides variant-disable-vjr">
                    <li class="col-sm-3 col-xs-6 wysiwyg">
                        <img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-1.png'); ?>">
                    </li>
                    <li class="col-sm-3 col-xs-6 wysiwyg">
                        <img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-2.png'); ?>">
                    </li>
                    <li class="col-sm-3 col-xs-6 wysiwyg">
                        <img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-3.png'); ?>">
                    </li>
                    <li class="col-sm-3 col-xs-6 wysiwyg">
                        <img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-4.png'); ?>">
                    </li>
                    <li class="col-sm-3 col-xs-6 wysiwyg">
                        <img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-5.png'); ?>">
                    </li>
                    <li class="col-sm-3 col-xs-6 wysiwyg">
                        <img alt="Image" class="image--xxs" src="<?php variant_page_builder_demo_img('partner-6.png'); ?>">
                    </li>
                </ul>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->