<!--META--><section class="vim" id="variant-team-carousel" vbr="Team Carousel" vbp="team">
<section class="switchable feature-large ">
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_team" data-param-layout="carousel" data-param-pppage="6" data-param-filter="all" data-param-offset="0"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->