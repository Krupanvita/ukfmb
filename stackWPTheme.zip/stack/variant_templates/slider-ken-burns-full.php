<!--META--><section class="vim" id="variant-slider-ken-burns-full" vbr="Slider Ken Burns Fullwidth" vbp="slider">
<section class="unpad--top unpad--bottom imagebg">
    <div class="slider slider--ken-burns variant-disable-vjr" data-arrows="true" data-paging="false">
        <ul class="slides variant-disable-vjr">
            <li>
                <img alt="Image" src="<?php variant_page_builder_demo_img('work-1.jpg'); ?>">
            </li>
            <li>
                <img alt="Image" src="<?php variant_page_builder_demo_img('work-2.jpg'); ?>">
            </li>
            <li>
                <img alt="Image" src="<?php variant_page_builder_demo_img('work-3.jpg'); ?>">
            </li>
            <li>
                <img alt="Image" src="<?php variant_page_builder_demo_img('work-4.jpg'); ?>">
            </li>
            <li>
                <img alt="Image" src="<?php variant_page_builder_demo_img('work-5.jpg'); ?>">
            </li>
            <li>
                <img alt="Image" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
            </li>
        </ul>
    </div>
</section>
</section><!--end of meta Section container-->