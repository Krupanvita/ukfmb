<!--META--><section class="vim" id="variant-section-title-1" vbr="Section Title 1" vbp="titles">
<section class="text-center ">
    
	<div class="container">
		<div class="row">
			<div class="col-sm-10 col-md-8 wysiwyg">
				<h2>Section Title Centered</h2>
				<p class="lead">
					Stack's visual style is simple yet distinct, making it an ideal starting point for your project whether it be a basic marketing site, or multi-page company presence.
				</p>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->