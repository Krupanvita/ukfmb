<!--META--><section class="vim" id="variant-features-large-9" vbr="Features Large 9" vbp="features large">
<section class="switchable switchable--switch imagebg height-50" data-overlay="2">
    <div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('inner-8.jpg'); ?>"></div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-6 wysiwyg">
                <h2>Design-driven and perfect for modern startups</h2>
                <p class="lead">
                    Stack offers a clean and contemporary to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.
                </p>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->