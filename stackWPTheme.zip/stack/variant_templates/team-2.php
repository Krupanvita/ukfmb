<!--META--><section class="vim" id="variant-team-2" vbr="Team 2" vbp="team">
<section class="text-center ">
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_team" data-param-layout="grid-2" data-param-pppage="3" data-param-filter="all" data-param-offset="0"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->