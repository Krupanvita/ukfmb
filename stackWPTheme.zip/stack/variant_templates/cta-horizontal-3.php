<!--META--><section class="vim" id="variant-cta-horizontal-3" vbr="CTA Horizontal 3" vbp="CTA">
<section class="text-center cta cta-4 space--xxs border--bottom ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <span class="label label--inline">Hot!</span>
                <span>Over 280 interface blocks, 140 demo pages and Variant Page Builder. <a href="#purchase-template">Purchase Stack</a> for $59 USD.</span>
            </div>  
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->