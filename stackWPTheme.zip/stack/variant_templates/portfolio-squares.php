<!--META--><section class="vim" id="variant-portfolio-squares" vbr="Portfolio Squares" vbp="portfolio">
<section class="text-center ">
	
	<div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_portfolio" data-param-layout="squares" data-param-pppage="3" data-param-filter="all" data-param-offset="0"></div>
	</div>
</section>
</section><!--end of meta Section container-->