<!--META--><section class="vim" id="variant-testimonial-avatar-2" vbr="Testimonial Avatar 2" vbp="testimonials">
<section class=" ">
	
	<div class="container">
		<div class="variant-shortcode" data-shortcode-name="stack_testimonial" data-param-layout="avatar" data-param-pppage="4" data-param-filter="all"></div>
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->