<!--META--><section class="vim" id="variant-cover-text-typed-1" vbr="Cover Text Typed 1" vbp="covers">
<section class="text-center">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="wysiwyg"><h6 class="type--uppercase">Introducing Stack</h6></div>
				<div class="typed-headline">
					<span class="h1 inline-block">The template for</span>
					<span class="h1 inline-block typed-text typed-text--cursor color--primary" data-typed-strings="bootstrapped startups.,marketing sites., portfolios.,blogging.,rapid development.,small business.,showcasing products., the design conscious."> </span>
				</div>
				<div class="wysiwyg">
				<p class="lead">
					A robust, multipurpose template built with modularity at the core. 
				</p>
				</div>
				<a class="btn btn--primary type--uppercase inner-link" href="#demos">
					<span class="btn__text">
						Explore Demos
					</span>
				</a>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->