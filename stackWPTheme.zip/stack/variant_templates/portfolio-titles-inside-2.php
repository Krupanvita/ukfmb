<!--META--><section class="vim" id="variant-portfolio-titles-inside-2" vbr="Portfolio Titles Inside 2 Columns" vbp="portfolio">
<section class="text-center ">
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_portfolio" data-param-layout="titles-inside-2" data-param-pppage="6" data-param-filter="all" data-param-offset="0"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->