<!--META--><section class="vim" id="variant-subscribe-image-1-gradient" vbr="Subscribe Image 1 Gradient" vbp="subscribes">
<section class="switchable imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-7 text-center">
                <img alt="Image" src="<?php variant_page_builder_demo_img('device-5.png'); ?>">
            </div>
            <div class="col-sm-5">
                <div class="switchable__text">
                	<div class="wysiwyg">
	                    <h2>Get hot monthly offers direct to your inbox</h2>
	                    <p class="lead">
	                        Build lean, beautiful websites with a clean and contemporary look to suit a range of purposes.
	                    </p>
                    </div>
                    <div class="cf7-holder">
                    	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                    		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                    	</div>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->