<!--META--><section class="vim" id="variant-cover-image-5" vbr="Cover Image 5" vbp="covers">
<section class="cover unpad--bottom switchable bg--secondary text-center-xs">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-md-5 mt--3">
				<div class="wysiwyg">
					<h1>
						Streamline your workflow with Stack
					</h1>
					<p class="lead">
						Build lean, beautiful websites with a clean and contemporary look to suit a range of purposes
					</p>
				</div>
				<a class="btn btn--primary type--uppercase" href="#customise-template">
					<span class="btn__text">
						Try Builder Live
					</span>
				</a>
				<div class="wysiwyg"><span class="block type--fine-print">or <a href="/">view the demos</a></span></div>
			</div>
			<div class="col-sm-6">
				<img alt="Image" src="<?php variant_page_builder_demo_img('avatar-large-3.png'); ?>">
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->