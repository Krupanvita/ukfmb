<!--META--><section class="vim" id="variant-team-single" vbr="Team Single" vbp="team">
<section class="switchable feature-large ">
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_team" data-param-layout="grid-1" data-param-pppage="1" data-param-filter="all" data-param-offset="0"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->