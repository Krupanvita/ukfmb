<!--META--><section class="vim" id="variant-slider-images-lightbox-2" vbr="Slider Images Lightbox 2" vbp="slider">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="slider slider--columns" data-arrows="true" data-paging="true">
                <ul class="slides">
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-6.jpg'); ?>" data-lightbox="Gallery 1" data-title="">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
                        </a>
						<div class="text-block">
							<h4>Gallery Item Title</h4>
							<p>Gallery Item Description</p>
						</div>
                    </li>
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-5.jpg'); ?>" data-lightbox="Gallery 1" data-title="">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-5.jpg'); ?>">
                        </a>
						<div class="text-block">
							<h4>Gallery Item Title</h4>
							<p>Gallery Item Description</p>
						</div>
                    </li>
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-4.jpg'); ?>" data-lightbox="Gallery 1" data-title="">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-4.jpg'); ?>">
                        </a>
						<div class="text-block">
							<h4>Gallery Item Title</h4>
							<p>Gallery Item Description</p>
						</div>
                    </li>
                    <li class="col-sm-4 col-xs-6">
                        <a href="<?php variant_page_builder_demo_img('work-3.jpg'); ?>" data-lightbox="Gallery 1" data-title="">
                            <img alt="Image" src="<?php variant_page_builder_demo_img('work-3.jpg'); ?>">
                        </a>
						<div class="text-block">
							<h4>Gallery Item Title</h4>
							<p>Gallery Item Description</p>
						</div>
                    </li>
                </ul>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->