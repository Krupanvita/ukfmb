<!--META--><section class="vim" id="variant-subscribe-title-3-gradient" vbr="Subscribe Title 3 Gradient" vbp="subscribes">
<section class="text-center imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="wysiwyg"><h2>Over 40,000 satisfied TommusRhodus customers</h2></div>
            <div class="cf7-holder">
            	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
            		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
            	</div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->