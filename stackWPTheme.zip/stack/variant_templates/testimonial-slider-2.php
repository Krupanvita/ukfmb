<!--META--><section class="vim" id="variant-testimonial-slider-2" vbr="Testimonial Slider 2" vbp="testimonials">
<section class="text-center ">
    
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-sm-10 variant-disable-vjr">
				<div class="variant-shortcode" data-shortcode-name="stack_testimonial" data-param-layout="slider-2" data-param-pppage="6" data-param-filter="all"></div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->