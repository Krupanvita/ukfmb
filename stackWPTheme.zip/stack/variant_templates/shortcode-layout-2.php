<!--META--><section class="vim" id="variant-shortcode-layout-2" vbr="Shortcode Layout 2" vbp="shortcodes">
<section class="text-center unpad--top unpad--bottom">
	<div class="shortcode-holder lead" data-shortcode="">Add your shortcode to the settings for this section &rarr;</div>
</section>
</section><!--end of meta Section container-->