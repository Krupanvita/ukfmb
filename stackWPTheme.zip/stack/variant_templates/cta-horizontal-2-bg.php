<!--META--><section class="vim" id="variant-cta-horizontal-2-bg" vbr="CTA Horizontal 2 BG" vbp="CTA">
<section class=" imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="cta cta-1 cta--horizontal boxed boxed--border text-center-xs">
                    <div class="col-md-3 col-md-offset-1">
                        <h4>Let's get you started</h4>
                    </div>
                    <div class="col-md-4">
                        <p class="lead">
                            Start building pages in your browser
                        </p>
                    </div>
                    <div class="col-md-4 text-center">
                        <a class="btn btn--primary type--uppercase" href="#">
                            <span class="btn__text">
                                Try Builder
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->