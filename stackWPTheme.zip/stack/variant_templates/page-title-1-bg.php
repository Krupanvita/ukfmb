<!--META--><section class="vim" id="variant-page-title-1-bg" vbr="Page Title 1 BG" vbp="titles">
<section class=" imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
	<div class="container">
		<div class="row">
			<div class="col-sm-12 wysiwyg">
				<h1>Simple Title</h1>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->